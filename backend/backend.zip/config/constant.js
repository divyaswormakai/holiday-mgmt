const DECISIONS = {
	ACCEPTED: 'ACCEPTED',
	REJECTED: 'REJECTED',
	PENDING: 'PENDING',
};
module.exports = { DECISIONS };
